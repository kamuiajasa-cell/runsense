class AthleteData {
  final String name;
  final double? ctl;
  final double? atl;
  final double? tsb;
  final double? lthr;
  final String? ltPace; // e.g. "5:32"
  final String goal; // 5K, 10K, etc
  final String? goalDate;
  final String coachingStyle; // conservative, moderate, aggressive

  AthleteData({
    required this.name,
    this.ctl,
    this.atl,
    this.tsb,
    this.lthr,
    this.ltPace,
    this.goal = '5K',
    this.goalDate,
    this.coachingStyle = 'moderate',
  });

  double get formScore {
    if (tsb == null) return 0;
    return tsb!;
  }

  String get formLabel {
    final t = tsb ?? 0;
    if (t >= 10) return 'Sangat Baik';
    if (t >= 0) return 'Baik';
    if (t >= -15) return 'Sedang';
    return 'Lelah';
  }
}

class DailyRecommendation {
  final String type; // Easy, Tempo, Interval, Recovery, Rest
  final String title;
  final String duration;
  final String hrZone;
  final String paceRange;
  final String reason;
  final bool isRestDay;

  DailyRecommendation({
    required this.type,
    required this.title,
    required this.duration,
    required this.hrZone,
    required this.paceRange,
    required this.reason,
    this.isRestDay = false,
  });
}

class GoalEstimate {
  final String distance;
  final String currentEstimate;
  final String goodCondition;
  final String tiredCondition;
  final String projection;
  final int secondsImproved;

  GoalEstimate({
    required this.distance,
    required this.currentEstimate,
    required this.goodCondition,
    required this.tiredCondition,
    required this.projection,
    this.secondsImproved = 0,
  });
}
