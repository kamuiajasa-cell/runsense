import 'package:flutter/foundation.dart';
import '../models/athlete_data.dart';
import 'intervals_service.dart';
import 'coach_engine.dart';

class AppState extends ChangeNotifier {
  bool isLoading = false;
  String? error;
  bool isLoggedIn = false;

  AthleteData? athlete;
  DailyRecommendation? recommendation;
  GoalEstimate? goalEstimate;
  List<dynamic> recentActivities = [];
  Map<String, double?> fitness = {};

  Future<void> initialize() async {
    final key = await IntervalsService.getApiKey();
    if (key != null && key.isNotEmpty) {
      await loadData(key);
    }
  }

  Future<bool> connect(String apiKey) async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      // Test connection
      final profile = await IntervalsService.getAthlete(apiKey);
      await IntervalsService.saveApiKey(apiKey);

      await loadData(apiKey, profile: profile);
      isLoggedIn = true;
      isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      error = e.toString().replaceAll('Exception: ', '');
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> loadData(String apiKey, {Map<String, dynamic>? profile}) async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      profile ??= await IntervalsService.getAthlete(apiKey);

      final activities = await IntervalsService.getRecentActivities(apiKey, days: 56);
      final wellness = await IntervalsService.getRecentWellness(apiKey, days: 42);

      recentActivities = activities;
      fitness = CoachEngine.extractFitness(wellness);

      final thresholds = CoachEngine.estimateThresholds(activities);
      final tsb = fitness['tsb'];

      athlete = AthleteData(
        name: profile['name'] ?? profile['firstname'] ?? 'Runner',
        ctl: fitness['ctl'],
        atl: fitness['atl'],
        tsb: tsb,
        lthr: thresholds['lthr'],
        ltPace: thresholds['ltPace'],
        goal: '5K',
      );

      recommendation = CoachEngine.generateRecommendation(
        tsb: tsb,
        recentActivities: activities,
        coachingStyle: 'moderate',
      );

      goalEstimate = CoachEngine.estimate5K(activities);

      isLoggedIn = true;
    } catch (e) {
      error = e.toString().replaceAll('Exception: ', '');
    }

    isLoading = false;
    notifyListeners();
  }

  Future<void> refresh() async {
    final key = await IntervalsService.getApiKey();
    if (key != null) {
      await loadData(key);
    }
  }

  Future<void> logout() async {
    await IntervalsService.clearApiKey();
    isLoggedIn = false;
    athlete = null;
    recommendation = null;
    goalEstimate = null;
    recentActivities = [];
    notifyListeners();
  }
}
