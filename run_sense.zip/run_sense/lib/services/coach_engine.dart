import '../models/athlete_data.dart';

/// Engine sederhana untuk menghasilkan rekomendasi harian
/// dan estimasi LTHR / LTPace / 5K berdasarkan data Intervals.icu
class CoachEngine {
  /// Estimasi LTHR & LTPace dari aktivitas terbaru
  static Map<String, dynamic> estimateThresholds(List<dynamic> activities) {
    // Cari aktivitas run yang cukup panjang & punya HR
    final candidates = activities.where((a) {
      final type = (a['type'] ?? '').toString().toLowerCase();
      final isRun = type.contains('run') || type.contains('virtual');
      final movingTime = a['moving_time'] ?? 0;
      final avgHr = a['average_heartrate'] ?? a['avg_hr'];
      return isRun && movingTime > 1200 && avgHr != null; // > 20 menit
    }).toList();

    if (candidates.isEmpty) {
      return {
        'lthr': 165.0,
        'ltPace': '5:40',
        'confidence': 'low',
        'message': 'Belum ada data yang cukup. Pakai nilai default dulu.',
      };
    }

    // Ambil beberapa sesi terkeras (berdasarkan icu_training_load atau intensity)
    candidates.sort((a, b) {
      final loadA = a['icu_training_load'] ?? a['icu_intensity'] ?? 0;
      final loadB = b['icu_training_load'] ?? b['icu_intensity'] ?? 0;
      return (loadB as num).compareTo(loadA as num);
    });

    final top = candidates.take(5).toList();

    // Average HR dari sesi-sesi keras sebagai pendekatan LTHR
    double totalHr = 0;
    int count = 0;
    for (final a in top) {
      final hr = a['average_heartrate'] ?? a['avg_hr'];
      if (hr != null) {
        totalHr += (hr as num).toDouble();
        count++;
      }
    }

    double estimatedLthr = count > 0 ? totalHr / count : 165.0;

    // Sedikit koreksi: untuk sesi < 30 menit biasanya HR sedikit lebih tinggi dari true LTHR
    estimatedLthr = estimatedLthr * 0.98;
    estimatedLthr = estimatedLthr.clamp(140.0, 195.0);

    // Estimasi pace threshold dari pace sesi terbaik
    String ltPace = '5:40';
    try {
      final best = top.first;
      final distance = (best['distance'] as num?)?.toDouble() ?? 0; // meter
      final moving = (best['moving_time'] as num?)?.toDouble() ?? 1;
      if (distance > 0) {
        final paceSecPerKm = (moving / (distance / 1000));
        // Threshold biasanya sedikit lebih lambat dari hard effort pendek
        final thresholdSec = paceSecPerKm * 1.06;
        ltPace = _formatPace(thresholdSec);
      }
    } catch (_) {}

    return {
      'lthr': estimatedLthr.roundToDouble(),
      'ltPace': ltPace,
      'confidence': candidates.length >= 3 ? 'medium' : 'low',
      'message': 'Berdasarkan ${candidates.length} sesi terakhir',
    };
  }

  /// Ambil CTL / ATL / TSB dari wellness data (Intervals.icu biasanya kirim di wellness)
  static Map<String, double?> extractFitness(List<dynamic> wellness) {
    if (wellness.isEmpty) {
      return {'ctl': null, 'atl': null, 'tsb': null};
    }

    // Ambil data terbaru
    final latest = wellness.last;
    final ctl = (latest['ctl'] as num?)?.toDouble();
    final atl = (latest['atl'] as num?)?.toDouble();
    double? tsb;
    if (ctl != null && atl != null) {
      tsb = ctl - atl;
    } else {
      tsb = (latest['tsb'] as num?)?.toDouble();
    }

    return {
      'ctl': ctl,
      'atl': atl,
      'tsb': tsb,
    };
  }

  /// Generate rekomendasi harian
  static DailyRecommendation generateRecommendation({
    required double? tsb,
    required List<dynamic> recentActivities,
    required String coachingStyle,
  }) {
    final now = DateTime.now();
    final last7Days = recentActivities.where((a) {
      final start = a['start_date_local'] ?? a['start_date'];
      if (start == null) return false;
      try {
        final dt = DateTime.parse(start.toString());
        return now.difference(dt).inDays <= 7;
      } catch (_) {
        return false;
      }
    }).toList();

    // Hitung berapa quality session 7 hari terakhir
    int qualityCount = 0;
    for (final a in last7Days) {
      final intensity = a['icu_intensity'] ?? 0;
      final load = a['icu_training_load'] ?? 0;
      if ((intensity as num) > 0.75 || (load as num) > 70) {
        qualityCount++;
      }
    }

    final tsbValue = tsb ?? 0;

    // Logika sederhana
    if (tsbValue < -25) {
      return DailyRecommendation(
        type: 'Rest',
        title: 'Istirahat Total',
        duration: '—',
        hrZone: '—',
        paceRange: '—',
        reason: 'Form sangat rendah (TSB ${tsbValue.toStringAsFixed(0)}). Tubuh butuh recovery.',
        isRestDay: true,
      );
    }

    if (tsbValue < -15 || qualityCount >= 3) {
      return DailyRecommendation(
        type: 'Recovery',
        title: 'Recovery Run',
        duration: '30–45 menit',
        hrZone: 'Zone 1–2',
        paceRange: 'Sangat mudah',
        reason: qualityCount >= 3
            ? 'Sudah $qualityCount quality session minggu ini. Saatnya recovery.'
            : 'Form masih negatif. Jaga tetap mudah.',
      );
    }

    if (tsbValue >= 5 && qualityCount < 2 && coachingStyle != 'conservative') {
      return DailyRecommendation(
        type: 'Tempo',
        title: 'Tempo Run',
        duration: '25–40 menit di threshold',
        hrZone: 'Zone 3–4',
        paceRange: 'Mendekati LTPace',
        reason: 'Form bagus dan quality session masih sedikit. Waktu yang tepat untuk tempo.',
      );
    }

    // Default: Easy
    return DailyRecommendation(
      type: 'Easy',
      title: 'Easy Run',
      duration: '40–60 menit',
      hrZone: 'Zone 2',
      paceRange: 'Nyaman, bisa bicara',
      reason: 'Bangun volume aerobik. Jaga tetap di Zone 2.',
    );
  }

  /// Estimasi kasar waktu 5K berdasarkan data terbaru
  static GoalEstimate estimate5K(List<dynamic> activities) {
    // Cari best recent effort (bisa 5K, 3K, atau tempo panjang)
    double? bestPaceSecPerKm;

    for (final a in activities) {
      final type = (a['type'] ?? '').toString().toLowerCase();
      if (!type.contains('run')) continue;

      final distance = (a['distance'] as num?)?.toDouble() ?? 0;
      final moving = (a['moving_time'] as num?)?.toDouble() ?? 0;
      if (distance < 2000 || moving < 600) continue;

      final pace = moving / (distance / 1000);
      if (bestPaceSecPerKm == null || pace < bestPaceSecPerKm) {
        // Hanya ambil effort yang cukup keras
        final intensity = a['icu_intensity'] ?? 0;
        if ((intensity as num) > 0.7 || distance > 4000) {
          bestPaceSecPerKm = pace;
        }
      }
    }

    if (bestPaceSecPerKm == null) {
      return GoalEstimate(
        distance: '5K',
        currentEstimate: '--:--',
        goodCondition: '--:--',
        tiredCondition: '--:--',
        projection: '--:--',
      );
    }

    // Konversi ke estimasi 5K (rule of thumb sederhana)
    // Effort keras 3-8km biasanya 3-8% lebih cepat dari true 5K race pace
    final estimated5kSec = bestPaceSecPerKm * 5 * 1.04;

    String format(double sec) {
      final m = (sec / 60).floor();
      final s = (sec % 60).round();
      return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }

    final current = format(estimated5kSec);
    final good = format(estimated5kSec * 0.985);
    final tired = format(estimated5kSec * 1.04);
    final projection = format(estimated5kSec * 0.96); // 6 minggu progress kasar

    return GoalEstimate(
      distance: '5K',
      currentEstimate: current,
      goodCondition: good,
      tiredCondition: tired,
      projection: projection,
      secondsImproved: 0,
    );
  }

  static String _formatPace(double secPerKm) {
    final m = (secPerKm / 60).floor();
    final s = (secPerKm % 60).round();
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}
