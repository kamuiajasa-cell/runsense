import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class IntervalsService {
  static const String _baseUrl = 'https://intervals.icu/api/v1';
  static const String _apiKeyKey = 'intervals_api_key';

  /// Save API key securely (for now using SharedPreferences)
  static Future<void> saveApiKey(String apiKey) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_apiKeyKey, apiKey.trim());
  }

  static Future<String?> getApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_apiKeyKey);
  }

  static Future<void> clearApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_apiKeyKey);
  }

  /// Basic Auth header: username = "API_KEY", password = actual key
  static Map<String, String> _authHeaders(String apiKey) {
    final credentials = base64Encode(utf8.encode('API_KEY:$apiKey'));
    return {
      'Authorization': 'Basic $credentials',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  /// Get athlete profile (id, name, zones, etc)
  static Future<Map<String, dynamic>> getAthlete(String apiKey) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/athlete/0'),
      headers: _authHeaders(apiKey),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else if (response.statusCode == 401) {
      throw Exception('API Key tidak valid');
    } else {
      throw Exception('Gagal ambil data athlete: ${response.statusCode}');
    }
  }

  /// Get activities in date range
  static Future<List<dynamic>> getActivities(
    String apiKey, {
    required DateTime oldest,
    required DateTime newest,
  }) async {
    final oldestStr = _formatDate(oldest);
    final newestStr = _formatDate(newest);

    final response = await http.get(
      Uri.parse('$_baseUrl/athlete/0/activities?oldest=$oldestStr&newest=$newestStr'),
      headers: _authHeaders(apiKey),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data is List) return data;
      return [];
    } else {
      throw Exception('Gagal ambil aktivitas: ${response.statusCode}');
    }
  }

  /// Get wellness data (includes CTL, ATL, TSB related fields)
  static Future<List<dynamic>> getWellness(
    String apiKey, {
    required DateTime oldest,
    required DateTime newest,
  }) async {
    final oldestStr = _formatDate(oldest);
    final newestStr = _formatDate(newest);

    final response = await http.get(
      Uri.parse('$_baseUrl/athlete/0/wellness?oldest=$oldestStr&newest=$newestStr'),
      headers: _authHeaders(apiKey),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data is List) return data;
      return [];
    } else {
      // Wellness kadang kosong, jangan throw keras
      return [];
    }
  }

  /// Get planned events / calendar
  static Future<List<dynamic>> getEvents(
    String apiKey, {
    required DateTime oldest,
    required DateTime newest,
  }) async {
    final oldestStr = _formatDate(oldest);
    final newestStr = _formatDate(newest);

    final response = await http.get(
      Uri.parse('$_baseUrl/athlete/0/events?oldest=$oldestStr&newest=$newestStr'),
      headers: _authHeaders(apiKey),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data is List) return data;
      return [];
    } else {
      return [];
    }
  }

  /// Convenience: get last N days of activities
  static Future<List<dynamic>> getRecentActivities(String apiKey, {int days = 42}) async {
    final newest = DateTime.now();
    final oldest = newest.subtract(Duration(days: days));
    return getActivities(apiKey, oldest: oldest, newest: newest);
  }

  /// Convenience: get recent wellness (for CTL/ATL/TSB)
  static Future<List<dynamic>> getRecentWellness(String apiKey, {int days = 42}) async {
    final newest = DateTime.now();
    final oldest = newest.subtract(Duration(days: days));
    return getWellness(apiKey, oldest: oldest, newest: newest);
  }

  static String _formatDate(DateTime d) {
    return '${d.year.toString().padLeft(4, '0')}-'
        '${d.month.toString().padLeft(2, '0')}-'
        '${d.day.toString().padLeft(2, '0')}';
  }
}
