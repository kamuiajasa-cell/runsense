import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../theme/app_theme.dart';
import '../services/app_state.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final activities = state.recentActivities.take(20).toList();

    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
              child: Text(
                'Riwayat',
                style: GoogleFonts.inter(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: activities.isEmpty
                  ? const Center(
                      child: Text(
                        'Belum ada aktivitas',
                        style: TextStyle(color: AppTheme.grey),
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                      itemCount: activities.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final a = activities[index];
                        final name = a['name'] ?? a['type'] ?? 'Aktivitas';
                        final distance = ((a['distance'] ?? 0) as num) / 1000;
                        final moving = (a['moving_time'] ?? 0) as num;
                        final load = a['icu_training_load'];
                        final start = a['start_date_local'] ?? a['start_date'];

                        String dateStr = '';
                        if (start != null) {
                          try {
                            final dt = DateTime.parse(start.toString());
                            dateStr = DateFormat('EEE, d MMM').format(dt);
                          } catch (_) {}
                        }

                        final minutes = (moving / 60).floor();
                        final seconds = (moving % 60).round();
                        final timeStr = '$minutes:${seconds.toString().padLeft(2, '0')}';

                        return Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: AppTheme.darkCard,
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      dateStr,
                                      style: GoogleFonts.inter(
                                        fontSize: 12,
                                        color: AppTheme.grey,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      name.toString(),
                                      style: GoogleFonts.inter(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${distance.toStringAsFixed(1)} km  •  $timeStr',
                                      style: GoogleFonts.inter(
                                        fontSize: 13,
                                        color: AppTheme.lightGrey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (load != null)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: AppTheme.primary.withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    'TL ${load.round()}',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: AppTheme.primary,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
