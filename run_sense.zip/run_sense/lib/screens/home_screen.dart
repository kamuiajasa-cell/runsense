import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../services/app_state.dart';
import '../widgets/recommendation_card.dart';
import '../widgets/goal_card.dart';
import '../widgets/form_badge.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final athlete = state.athlete;
    final recommendation = state.recommendation;
    final goal = state.goalEstimate;

    if (state.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator(color: AppTheme.primary)),
      );
    }

    if (athlete == null || recommendation == null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Belum ada data', style: TextStyle(color: Colors.white)),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => state.refresh(),
                child: const Text('Refresh'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: AppTheme.primary,
          onRefresh: () => state.refresh(),
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Selamat pagi',
                                style: GoogleFonts.inter(
                                  fontSize: 15,
                                  color: AppTheme.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                athlete.name,
                                style: GoogleFonts.inter(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                          FormBadge(label: athlete.formLabel, tsb: athlete.tsb ?? 0),
                        ],
                      ).animate().fadeIn(duration: 400.ms).slideY(begin: -0.1),

                      const SizedBox(height: 28),

                      // Recommendation Card
                      RecommendationCard(recommendation: recommendation)
                          .animate()
                          .fadeIn(delay: 100.ms, duration: 500.ms)
                          .slideY(begin: 0.1),

                      const SizedBox(height: 20),

                      // Goal Card
                      if (goal != null)
                        GoalCard(goal: goal)
                            .animate()
                            .fadeIn(delay: 200.ms, duration: 500.ms)
                            .slideY(begin: 0.1),

                      const SizedBox(height: 28),

                      // Quick stats
                      Text(
                        'RINGKASAN',
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.grey,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _StatBox(label: 'CTL', value: athlete.ctl?.toStringAsFixed(1) ?? '-'),
                          const SizedBox(width: 12),
                          _StatBox(label: 'ATL', value: athlete.atl?.toStringAsFixed(1) ?? '-'),
                          const SizedBox(width: 12),
                          _StatBox(label: 'TSB', value: athlete.tsb?.toStringAsFixed(1) ?? '-'),
                        ],
                      ).animate().fadeIn(delay: 300.ms),

                      const SizedBox(height: 16),
                      if (athlete.lthr != null || athlete.ltPace != null)
                        Text(
                          'LTHR ~ ${athlete.lthr?.round() ?? '-'} bpm  •  LTPace ~ ${athlete.ltPace ?? '-'}',
                          style: GoogleFonts.inter(
                            fontSize: 13,
                            color: AppTheme.grey,
                          ),
                        ),

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String label;
  final String value;

  const _StatBox({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: AppTheme.darkCard,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 12,
                color: AppTheme.grey,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: GoogleFonts.inter(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
