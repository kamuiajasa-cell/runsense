import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../services/app_state.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _apiKeyController = TextEditingController();
  String _selectedGoal = '5K';
  String _coachingStyle = 'moderate';
  bool _isConnecting = false;

  Future<void> _connect() async {
    final key = _apiKeyController.text.trim();
    if (key.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('API Key wajib diisi')),
      );
      return;
    }

    setState(() => _isConnecting = true);

    final state = context.read<AppState>();
    final success = await state.connect(key);

    setState(() => _isConnecting = false);

    if (!success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(state.error ?? 'Gagal terhubung'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              Text(
                'RunSense',
                style: GoogleFonts.inter(
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.primary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Setup cepat, langsung pakai',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  color: AppTheme.grey,
                ),
              ),
              const SizedBox(height: 40),

              // API Key
              Text(
                'API KEY INTERVALS.ICU',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.grey,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _apiKeyController,
                obscureText: true,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Paste API key di sini',
                  hintStyle: TextStyle(color: AppTheme.grey.withOpacity(0.6)),
                  filled: true,
                  fillColor: AppTheme.darkCard,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Ambil di Intervals.icu → Settings → Developer',
                style: GoogleFonts.inter(fontSize: 12, color: AppTheme.grey),
              ),

              const SizedBox(height: 36),

              // Goal
              Text(
                'TARGET UTAMA',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.grey,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: ['5K', '10K', 'Half', 'Marathon', 'Umum'].map((g) {
                  final selected = _selectedGoal == g;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedGoal = g),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      decoration: BoxDecoration(
                        color: selected ? AppTheme.primary : AppTheme.darkCard,
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Text(
                        g,
                        style: GoogleFonts.inter(
                          fontWeight: FontWeight.w600,
                          color: selected ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 36),

              // Coaching style
              Text(
                'GAYA COACHING',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.grey,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              _StyleOption(
                title: 'Konservatif',
                subtitle: 'Lebih banyak recovery',
                selected: _coachingStyle == 'conservative',
                onTap: () => setState(() => _coachingStyle = 'conservative'),
              ),
              const SizedBox(height: 10),
              _StyleOption(
                title: 'Moderat',
                subtitle: 'Seimbang (disarankan)',
                selected: _coachingStyle == 'moderate',
                onTap: () => setState(() => _coachingStyle = 'moderate'),
              ),
              const SizedBox(height: 10),
              _StyleOption(
                title: 'Agresif',
                subtitle: 'Lebih banyak quality session',
                selected: _coachingStyle == 'aggressive',
                onTap: () => setState(() => _coachingStyle = 'aggressive'),
              ),

              const SizedBox(height: 48),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isConnecting ? null : _connect,
                  child: _isConnecting
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.black,
                          ),
                        )
                      : const Text('Hubungkan & Mulai'),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _StyleOption extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  const _StyleOption({
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppTheme.darkCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? AppTheme.primary : Colors.transparent,
            width: 1.5,
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: GoogleFonts.inter(
                      fontSize: 13,
                      color: AppTheme.grey,
                    ),
                  ),
                ],
              ),
            ),
            if (selected)
              const Icon(Icons.check_circle_rounded, color: AppTheme.primary, size: 24),
          ],
        ),
      ),
    );
  }
}
