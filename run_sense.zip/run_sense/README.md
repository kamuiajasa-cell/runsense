# RunSense

Aplikasi pendamping lari otomatis berbasis **Intervals.icu**.

UI dark mode bergaya Adidas Running. Cukup paste API key, lalu app yang handle sisanya.

## Fitur

- Paste API Key Intervals.icu → data langsung ditarik
- Rekomendasi harian (Easy / Tempo / Recovery / Rest) berdasarkan form (TSB) + riwayat
- Estimasi otomatis **LTHR** & **LTPace**
- Estimasi waktu **5K**
- CTL / ATL / TSB
- Riwayat aktivitas
- Pull-to-refresh

## Cara setup dari GitHub

### 1. Clone repo

```bash
git clone https://github.com/USERNAME/run_sense.git
cd run_sense
```

### 2. Generate platform folders (wajib sekali)

Karena repo ini hanya berisi kode Dart, jalankan:

```bash
flutter create . --project-name run_sense --org com.runsense.app
```

Ini akan membuat folder `android/`, `ios/`, dll tanpa menimpa file `lib/` yang sudah ada.

### 3. Install dependency & jalankan

```bash
flutter pub get
flutter run
```

## Alur di app

1. Buka app → paste **API Key** dari Intervals.icu  
   (Settings → Developer → API Key)
2. App otomatis:
   - Ambil profil athlete
   - Ambil aktivitas ~8 minggu terakhir
   - Ambil wellness (CTL/ATL)
   - Hitung estimasi LTHR, LTPace, dan rekomendasi hari ini
3. Setiap hari buka **Beranda** untuk lihat rekomendasi

## Struktur

```
lib/
├── main.dart
├── services/
│   ├── intervals_service.dart   # API Intervals.icu
│   ├── coach_engine.dart        # Logika rekomendasi + estimasi
│   └── app_state.dart           # State (Provider)
├── screens/
│   ├── setup_screen.dart
│   ├── home_screen.dart
│   ├── progress_screen.dart
│   └── history_screen.dart
├── widgets/
├── models/
└── theme/
```

## Catatan teknis

- Auth: HTTP Basic (`API_KEY` : `your_key`)
- Athlete ID memakai `0` (otomatis user pemilik key)
- Estimasi LTHR/LTPace masih heuristik (akan diperbaiki seiring data bertambah)
- Belum ada upload aktivitas (cukup baca dari Intervals.icu)

## License

MIT
